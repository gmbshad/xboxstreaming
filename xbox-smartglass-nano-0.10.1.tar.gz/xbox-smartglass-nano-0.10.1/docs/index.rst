.. Xbox-Smartglass-Nano documentation master file, created by
   sphinx-quickstart on Fri Mar  9 07:54:03 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Xbox-Smartglass-Nano's documentation!
================================================

.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   source/xbox.nano.manager
   source/xbox.nano.protocol



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
