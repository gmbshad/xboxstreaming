xbox.nano.packet.control module
===============================

.. automodule:: xbox.nano.packet.control
    :members:
    :undoc-members:
    :show-inheritance:
