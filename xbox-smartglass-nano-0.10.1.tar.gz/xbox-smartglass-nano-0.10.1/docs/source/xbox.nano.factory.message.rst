xbox.nano.factory.message module
================================

.. automodule:: xbox.nano.factory.message
    :members:
    :undoc-members:
    :show-inheritance:
