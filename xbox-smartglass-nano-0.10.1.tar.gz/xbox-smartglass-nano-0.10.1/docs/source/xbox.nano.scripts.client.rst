xbox.nano.scripts.client module
===============================

.. automodule:: xbox.nano.scripts.client
    :members:
    :undoc-members:
    :show-inheritance:
