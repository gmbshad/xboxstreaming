xbox.nano.scripts.client\_mp module
===================================

.. automodule:: xbox.nano.scripts.client_mp
    :members:
    :undoc-members:
    :show-inheritance:
