xbox.nano.factory.channel module
================================

.. automodule:: xbox.nano.factory.channel
    :members:
    :undoc-members:
    :show-inheritance:
