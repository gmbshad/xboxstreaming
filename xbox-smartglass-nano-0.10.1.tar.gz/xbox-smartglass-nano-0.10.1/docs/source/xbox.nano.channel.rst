xbox.nano.channel module
========================

.. automodule:: xbox.nano.channel
    :members:
    :undoc-members:
    :show-inheritance:
