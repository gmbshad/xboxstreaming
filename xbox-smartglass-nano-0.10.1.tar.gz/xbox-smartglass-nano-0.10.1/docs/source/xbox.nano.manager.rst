xbox.nano.manager module
========================

.. automodule:: xbox.nano.manager
    :members:
    :undoc-members:
    :show-inheritance:
