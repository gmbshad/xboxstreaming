xbox.nano.factory.control module
================================

.. automodule:: xbox.nano.factory.control
    :members:
    :undoc-members:
    :show-inheritance:
