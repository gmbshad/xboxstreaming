xbox.nano.packet.fec module
===========================

.. automodule:: xbox.nano.packet.fec
    :members:
    :undoc-members:
    :show-inheritance:
