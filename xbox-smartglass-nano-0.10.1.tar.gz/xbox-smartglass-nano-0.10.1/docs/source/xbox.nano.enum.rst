xbox.nano.enum module
=====================

.. automodule:: xbox.nano.enum
    :members:
    :undoc-members:
    :show-inheritance:
