xbox.nano.factory.input module
==============================

.. automodule:: xbox.nano.factory.input
    :members:
    :undoc-members:
    :show-inheritance:
