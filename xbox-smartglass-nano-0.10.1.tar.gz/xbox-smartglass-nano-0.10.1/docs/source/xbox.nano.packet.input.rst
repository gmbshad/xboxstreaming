xbox.nano.packet.input module
=============================

.. automodule:: xbox.nano.packet.input
    :members:
    :undoc-members:
    :show-inheritance:
