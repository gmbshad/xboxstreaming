xbox.nano.packet.message module
===============================

.. automodule:: xbox.nano.packet.message
    :members:
    :undoc-members:
    :show-inheritance:
