xbox.nano.render.audio.aac module
=================================

.. automodule:: xbox.nano.render.audio.aac
    :members:
    :undoc-members:
    :show-inheritance:
