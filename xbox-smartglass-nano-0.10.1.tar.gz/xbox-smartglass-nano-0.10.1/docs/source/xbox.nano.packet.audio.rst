xbox.nano.packet.audio module
=============================

.. automodule:: xbox.nano.packet.audio
    :members:
    :undoc-members:
    :show-inheritance:
