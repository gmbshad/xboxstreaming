# -*- coding: utf-8 -*-

"""Top-level package for xbox-smartglass-nano-python."""

__author__ = """OpenXbox"""
__version__ = '0.10.1'
